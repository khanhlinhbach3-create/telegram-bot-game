import telebot
import os
import random
import time
from flask import Flask
from threading import Thread

# ------------------------
# Flask web server để keep alive
# ------------------------
app = Flask('')

@app.route('/')
def home():
    return "🤖 Bot is alive!"

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.start()

# ------------------------
# Khởi tạo Bot
# ------------------------
TOKEN = os.environ.get("BOT_TOKEN") or "8201227255:AAESGnWEFTU8JP477NzVK8e0wzk0H4RSabE"
bot = telebot.TeleBot(TOKEN)

# Hàm kiểm tra quyền admin trong nhóm
def is_admin(message):
    try:
        # Kiểm tra nếu là chủ nhóm ẩn danh
        if message.from_user.is_bot and message.from_user.first_name == "Group":
            return True
        
        # Kiểm tra quyền admin thông thường
        chat_member = bot.get_chat_member(message.chat.id, message.from_user.id)
        return chat_member.status in ['administrator', 'creator']
    except:
        return False

# ------------------------
# Danh sách câu hỏi đố vui
# ------------------------
questions = [
    {"q": "🌍 Trái đất có mấy châu lục?", "a": "7"},
    {"q": "🪐 Hành tinh nào lớn nhất trong Hệ Mặt Trời?", "a": "Sao Mộc"},
    {"q": "⚡ Ai phát minh ra bóng đèn?", "a": "Edison"},
    {"q": "🌡 Nhiệt độ nước sôi ở mức bao nhiêu °C?", "a": "100"},
    {"q": "🐼 Quốc gia nào nổi tiếng với gấu trúc?", "a": "Trung Quốc"},
    {"q": "🍜 Mì Ramen có nguồn gốc từ nước nào?", "a": "Nhật Bản"},
    {"q": "🦁 Loài vật nào được mệnh danh là 'chúa sơn lâm'?", "a": "Sư tử"},
    {"q": "🐱 Con mèo có mấy chân?", "a": "4"},
    {"q": "🐶 Con chó thuộc loài động vật gì?", "a": "Có vú"},
    {"q": "🇻🇳 Thủ đô của Việt Nam là gì?", "a": "Hà Nội"},
    {"q": "🇨🇳 Thủ đô của Trung Quốc là gì?", "a": "Bắc Kinh"},
    {"q": "🇯🇵 Thủ đô của Nhật Bản là gì?", "a": "Tokyo"},
    {"q": "🇫🇷 Thủ đô của Pháp là gì?", "a": "Paris"},
    {"q": "🇺🇸 Thủ đô của Mỹ là gì?", "a": "Washington"},
    {"q": "💻 Ai là người sáng lập Microsoft?", "a": "Bill Gates"},
    {"q": "📱 Ai là người sáng lập Apple?", "a": "Steve Jobs"},
    {"q": "📱 Hệ điều hành của iPhone tên là gì?", "a": "iOS"},
    {"q": "📱 Hệ điều hành của điện thoại Samsung phổ biến là gì?", "a": "Android"},
    {"q": "🎬 Bộ phim 'Titanic' ra mắt năm nào?", "a": "1997"},
    {"q": "🎤 Ai là 'ông hoàng nhạc Pop'?", "a": "Michael Jackson"},
    {"q": "🎸 Ban nhạc huyền thoại 'Yesterday' là ai?", "a": "The Beatles"},
    {"q": "🏀 Michael Jordan nổi tiếng với môn thể thao nào?", "a": "Bóng rổ"},
    {"q": "⚽ Cristiano Ronaldo mang áo số mấy ở Real Madrid (giai đoạn đỉnh cao)?", "a": "7"},
    {"q": "⚽ Lionel Messi đến từ quốc gia nào?", "a": "Argentina"},
    {"q": "🥇 Olympic tổ chức bao nhiêu năm 1 lần?", "a": "4"},
    {"q": "🧪 Nước có công thức hóa học là gì?", "a": "H2O"},
    {"q": "🔥 Kim loại nào nóng chảy ở nhiệt độ thấp nhất?", "a": "Thủy ngân"},
    {"q": "🧬 ADN là viết tắt của gì? (tiếng Anh)", "a": "Deoxyribonucleic acid"},
    {"q": "🔢 Số nguyên tố đầu tiên là gì?", "a": "2"},
    {"q": "📐 Góc vuông bao nhiêu độ?", "a": "90"},
    {"q": "📏 Một mét có bao nhiêu xăng-ti-mét?", "a": "100"},
    {"q": "🕰 Một ngày có bao nhiêu giờ?", "a": "24"},
    {"q": "📅 Một năm nhuận có bao nhiêu ngày?", "a": "366"},
    {"q": "📚 'Truyện Kiều' do ai sáng tác?", "a": "Nguyễn Du"},
    {"q": "📚 Tác giả 'Dế Mèn Phiêu Lưu Ký' là ai?", "a": "Tô Hoài"},
    {"q": "📚 'Harry Potter' do ai viết?", "a": "J.K. Rowling"},
    {"q": "🎨 Leonardo da Vinci vẽ bức tranh nổi tiếng nào?", "a": "Mona Lisa"},
    {"q": "🗽 Tượng Nữ thần Tự do ở thành phố nào?", "a": "New York"},
    {"q": "🗻 Núi cao nhất thế giới là gì?", "a": "Everest"},
    {"q": "🏝 Quốc gia nào có nhiều đảo nhất thế giới?", "a": "Indonesia"},
    {"q": "🕌 Đạo Hồi gọi nơi cầu nguyện là gì?", "a": "Nhà thờ Hồi giáo"},
    {"q": "⛪ Người theo đạo Thiên Chúa cầu nguyện ở đâu?", "a": "Nhà thờ"},
    {"q": "🐒 Con vật nào gần gũi với loài người nhất?", "a": "Khỉ"},
    {"q": "🦕 Khủng long tuyệt chủng cách đây bao nhiêu triệu năm?", "a": "65"},
    {"q": "💉 Ai phát minh ra vắc-xin phòng bệnh dại?", "a": "Pasteur"},
    {"q": "🚀 Người đầu tiên đặt chân lên Mặt Trăng là ai?", "a": "Neil Armstrong"},
    {"q": "🇻🇳 Quốc khánh Việt Nam là ngày nào?", "a": "2/9"},
    {"q": "🇻🇳 Bác Hồ sinh năm bao nhiêu?", "a": "1890"},
    {"q": "🇻🇳 Sông dài nhất Việt Nam là gì?", "a": "Sông Mekong"},
    # 100 câu hỏi mới từ file đính kèm
    {"q": "➕ 1 + 1 = ?", "a": "2"},
    {"q": "🪐 Hành tinh nào gần Mặt Trời nhất?", "a": "Sao Thủy"},
    {"q": "📅 Năm có bao nhiêu tháng?", "a": "12"},
    {"q": "🌊 Hà Nội nằm bên bờ con sông nào?", "a": "Sông Hồng"},
    {"q": "🧬 Nguyên tố nào có ký hiệu O?", "a": "Oxy"},
    {"q": "🌸 Loài hoa nào được chọn làm quốc hoa của Việt Nam?", "a": "Hoa sen"},
    {"q": "🏆 Quốc gia nào vô địch World Cup 2018?", "a": "Pháp"},
    {"q": "📖 Tác giả 'Dế Mèn Phiêu Lưu Ký' là ai?", "a": "Tô Hoài"},
    {"q": "📜 Câu ca dao: Công cha như núi Thái Sơn, nghĩa mẹ như…?", "a": "Nước trong nguồn"},
    {"q": "🦴 Cơ thể người có bao nhiêu xương?", "a": "206"},
    {"q": "🚢 Bến Nhà Rồng gắn liền với ai?", "a": "Hồ Chí Minh"},
    {"q": "🥁 Con gì ăn no bụng to mắt híp?", "a": "Cái trống"},
    {"q": "🏛 Việt Nam có bao nhiêu tỉnh thành (2023)?", "a": "63"},
    {"q": "⚽ Cầu thủ nào được gọi là 'Rô béo'?", "a": "Ronaldo"},
    {"q": "🇰🇷 Thủ đô của Hàn Quốc là gì?", "a": "Seoul"},
    {"q": "🎨 Bức tranh Mona Lisa do ai vẽ?", "a": "Leonardo da Vinci"},
    {"q": "🧩 Con gì 4 chân buổi sáng, 2 chân buổi trưa, 3 chân buổi tối?", "a": "Con người"},
    {"q": "👥 Dân số Việt Nam khoảng bao nhiêu (2023)?", "a": "100 triệu"},
    {"q": "🎊 Tết Nguyên Đán còn gọi là gì?", "a": "Tết Cổ truyền"},
    {"q": "🌊 Sông nào dài nhất thế giới?", "a": "Sông Nile"},
    {"q": "💓 Con gì đập thì sống, để yên thì chết?", "a": "Trái tim"},
    {"q": "📅 Năm có bao nhiêu ngày thường?", "a": "365"},
    {"q": "📚 Ngày Nhà giáo Việt Nam?", "a": "20/11"},
    {"q": "🕊 Loài chim biểu tượng hòa bình?", "a": "Bồ câu"},
    {"q": "📱 Hãng điện thoại iPhone thuộc công ty nào?", "a": "Apple"},
    {"q": "⚽ Cầu thủ nào được gọi là M10?", "a": "Messi"},
    {"q": "🏛 Tỉnh nào có tháp Chăm Mỹ Sơn?", "a": "Quảng Nam"},
    {"q": "🌏 Quốc gia đông dân nhất thế giới?", "a": "Trung Quốc"},
    {"q": "📖 Truyện 'Lão Hạc' do ai viết?", "a": "Nam Cao"},
    {"q": "🦇 Động vật nào có vú mà biết bay?", "a": "Dơi"},
    {"q": "🎵 Ai được mệnh danh là 'Ông vua nhạc Pop'?", "a": "Michael Jackson"},
    {"q": "🛠 Ngày Quốc tế Lao động?", "a": "1/5"},
    {"q": "🌍 Hành tinh xanh là hành tinh nào?", "a": "Trái Đất"},
    {"q": "🇻🇳 Quốc kỳ Việt Nam có màu gì?", "a": "Đỏ và vàng"},
    {"q": "🌺 Hà Giang nổi tiếng với loại hoa gì?", "a": "Tam giác mạch"},
    {"q": "🏞 Vịnh nào được UNESCO công nhận là di sản thiên nhiên thế giới ở Việt Nam?", "a": "Vịnh Hạ Long"},
    {"q": "🌍 Quốc gia nào có diện tích lớn nhất thế giới?", "a": "Nga"},
    {"q": "📖 Tác giả 'Chí Phèo' là ai?", "a": "Nam Cao"},
    {"q": "🪑 Con gì đi thì nằm, đứng thì ngồi?", "a": "Cái bàn"},
    {"q": "⚽ Người ta hay gọi ai là 'ông hoàng bóng đá'?", "a": "Pele"},
    {"q": "🐋 Loài cá nào to nhất thế giới?", "a": "Cá mập voi"},
    {"q": "💰 Đồng tiền của Nhật Bản?", "a": "Yên"},
    {"q": "💡 Ai sáng chế ra bóng đèn?", "a": "Thomas Edison"},
    {"q": "🏛 Hà Nội có bao nhiêu quận nội thành (2023)?", "a": "12"},
    {"q": "🌸 Ngày Quốc tế Phụ nữ?", "a": "8/3"},
    {"q": "🐘 Động vật nào có trí nhớ tốt nhất?", "a": "Voi"},
    {"q": "🌹 Thành phố nào được gọi là 'thành phố ngàn hoa'?", "a": "Đà Lạt"},
    {"q": "🕯 Con gì càng già càng ngắn?", "a": "Cây nến"},
    {"q": "🏝 Đảo nào lớn nhất Việt Nam?", "a": "Phú Quốc"},
    {"q": "🗼 Tháp Eiffel nằm ở thành phố nào?", "a": "Paris"},
    {"q": "🧠 Ai là cha đẻ của Thuyết Tương đối?", "a": "Albert Einstein"},
    {"q": "⛰ Ngọn núi nào cao nhất Việt Nam?", "a": "Fansipan"},
    {"q": "🍉 Trái cây nào tượng trưng cho sự sung túc ngày Tết?", "a": "Dưa hấu"},
    {"q": "🇺🇸 Quốc kỳ Mỹ có bao nhiêu ngôi sao?", "a": "50"},
    {"q": "💡 Con gì không bao giờ ngã?", "a": "Bóng đèn"},
    {"q": "🎊 Ngày Giải phóng miền Nam?", "a": "30/4"},
    {"q": "🐊 Loài cá nào có thể sống cả trên cạn?", "a": "Cá sấu"},
    {"q": "🇧🇷 Ngôn ngữ chính thức của Brazil?", "a": "Tiếng Bồ Đào Nha"},
    {"q": "📖 Truyện 'Vợ nhặt' của ai?", "a": "Kim Lân"},
    {"q": "🪐 Hành tinh nào có vòng đẹp nhất?", "a": "Sao Thổ"},
    {"q": "🌹 Loài hoa nào được gọi là nữ hoàng của các loài hoa?", "a": "Hoa hồng"},
    {"q": "🇹🇭 Thủ đô của Thái Lan?", "a": "Bangkok"},
    {"q": "🐋 Động vật nào to nhất trên Trái Đất?", "a": "Cá voi xanh"},
    {"q": "🇨🇳 Quốc kỳ Trung Quốc có màu gì?", "a": "Đỏ và vàng"},
    {"q": "👑 Loài cây nào được gọi là vua của các loại trái cây?", "a": "Sầu riêng"},
    {"q": "📖 Ai viết 'Tắt đèn'?", "a": "Ngô Tất Tố"},
    {"q": "🐆 Động vật nào có tốc độ chạy nhanh nhất?", "a": "Báo gêpa"},
    {"q": "🇮🇹 Quốc gia nào nổi tiếng với Tháp nghiêng Pisa?", "a": "Ý"},
    {"q": "🌍 Ngày Trái Đất?", "a": "22/4"},
    {"q": "🍇 Trái cây nào thường được dùng để làm rượu vang?", "a": "Nho"},
    {"q": "🐍 Con gì 99 đầu 1 cổ?", "a": "Con rắn"},
    {"q": "♟ Cờ vua có bao nhiêu quân cờ?", "a": "32"},
    {"q": "🇪🇬 Quốc gia nào nổi tiếng với Kim Tự Tháp?", "a": "Ai Cập"},
    {"q": "🚀 Người Việt Nam đầu tiên bay vào vũ trụ?", "a": "Phạm Tuân"},
    {"q": "💧 Con gì càng rửa càng bẩn?", "a": "Nước"},
    {"q": "🐢 Động vật nào có tuổi thọ cao nhất?", "a": "Rùa"},
    {"q": "🇨🇦 Quốc gia nào có lá phong trên quốc kỳ?", "a": "Canada"},
    {"q": "🎼 Ai được mệnh danh là 'thần đồng âm nhạc'?", "a": "Mozart"},
    {"q": "🌞 Trái đất quay quanh gì?", "a": "Mặt Trời"},
    {"q": "🏆 Người Việt Nam đầu tiên đoạt giải Nobel?", "a": "Chưa có"},
    {"q": "🇺🇸 Ai là Tổng thống Mỹ thứ 44?", "a": "Barack Obama"},
    {"q": "🦈 Loài cá nào có thể phát sáng?", "a": "Cá mập"},
    {"q": "👶 Ngày Quốc tế Thiếu nhi?", "a": "1/6"},
    {"q": "🕳 Cái gì càng lấy đi càng lớn?", "a": "Cái hố"},
    {"q": "🌊 Đại dương nào lớn nhất?", "a": "Thái Bình Dương"},
    {"q": "🦘 Động vật nào có túi trước bụng?", "a": "Kangaroo"},
    {"q": "🇩🇪 Quốc kỳ Đức có mấy màu?", "a": "3"},
    {"q": "⚽ Cầu thủ nào được gọi là CR7?", "a": "Cristiano Ronaldo"},
    {"q": "🇷🇺 Thủ đô của Nga là gì?", "a": "Moskva"}
]

# ------------------------
# Danh sách hình phạt / thưởng
# ------------------------
rewards = [
    "🎉 Nhận một tràng pháo tay 👏",
    "🍬 Được thưởng 1 viên kẹo (ảo thôi 😆)",
    "💎 Nhận 100 điểm may mắn!",
    "🎤 Được quyền ra câu hỏi tiếp theo",
    "🍀 Hôm nay sẽ gặp may mắn!"
]

punishments = [
    "😈 Hát 1 bài ngay lập tức!",
    "😂 Kể 1 câu chuyện cười",
    "💃 Nhảy một điệu bất kỳ",
    "📸 Chụp 1 tấm ảnh selfie đăng nhóm",
    "💪 Làm 10 cái chống đẩy"
]

# ------------------------
# GAME ĐỐ VUI
# ------------------------
current_question = {}
used_questions = {}  # Lưu danh sách câu hỏi đã dùng cho mỗi chat
quiz_answers = {}    # Lưu câu trả lời của từng người chơi trong câu hỏi hiện tại
quiz_participants = {}  # Lưu danh sách người đã trả lời để tránh trả lời nhiều lần

def countdown_timer(chat_id):
    """Đếm ngược 30 giây cho câu hỏi"""
    time.sleep(25)  # Đợi 25 giây
    if chat_id in current_question:
        bot.send_message(chat_id, "⏰ Còn 5 giây!")
    
    time.sleep(5)  # Đợi thêm 5 giây nữa (tổng 30 giây)
    if chat_id in current_question:
        end_quiz(chat_id)

def end_quiz(chat_id):
    """Kết thúc câu hỏi và thống kê kết quả"""
    if chat_id not in current_question:
        return
    
    q = current_question[chat_id]
    
    # Thống kê kết quả
    correct_users = []
    wrong_users = []
    
    if chat_id in quiz_answers:
        for user_id, answer_data in quiz_answers[chat_id].items():
            if answer_data['is_correct']:
                correct_users.append(answer_data['user_name'])
            else:
                wrong_users.append(f"{answer_data['user_name']} ({answer_data['answer']})")
    
    # Thông báo kết quả
    result_msg = f"⏰ Hết giờ!\n"
    result_msg += f"📝 Đáp án: {q['a']}\n\n"
    result_msg += f"📊 Kết quả ({len(quiz_answers[chat_id] if chat_id in quiz_answers else {})} người tham gia):\n\n"
    
    if correct_users:
        result_msg += f"✅ Trả lời đúng ({len(correct_users)} người):\n"
        for i, user in enumerate(correct_users, 1):
            result_msg += f"{i}. {user}\n"
        result_msg += "\n"
    
    if wrong_users:
        result_msg += f"❌ Trả lời sai ({len(wrong_users)} người):\n"
        for i, user in enumerate(wrong_users, 1):
            result_msg += f"{i}. {user}\n"
    
    if not correct_users and not wrong_users:
        result_msg += "😴 Không có ai trả lời!"
    
    bot.send_message(chat_id, result_msg)
    
    # Xóa dữ liệu câu hỏi hiện tại
    if chat_id in current_question:
        del current_question[chat_id]
    if chat_id in quiz_answers:
        del quiz_answers[chat_id]
    if chat_id in quiz_participants:
        del quiz_participants[chat_id]

@bot.message_handler(commands=['quiz'])
def quiz(message):
    chat_id = message.chat.id

    # Kiểm tra quyền admin trong nhóm
    if not is_admin(message):
        bot.send_message(chat_id, "Bạn có phải chủ của tớ đâu mờ nhắn lệnh /quiz 🤭")
        return

    # Kiểm tra xem có câu hỏi đang diễn ra không
    if chat_id in current_question:
        bot.send_message(chat_id, "⚠️ Đang có câu hỏi, đợi kết thúc rồi hãy bắt đầu câu mới!")
        return

    # Khởi tạo danh sách câu hỏi đã dùng nếu chưa có
    if chat_id not in used_questions:
        used_questions[chat_id] = []

    # Nếu đã hết câu hỏi, thông báo đợi admin
    if len(used_questions[chat_id]) >= len(questions):
        bot.send_message(chat_id, "Hết câu hỏi mất rùi, đợi mình nhắn thằng cha admin nha 😤")
        return

    # Chọn câu hỏi chưa được dùng
    available_questions = [q for q in questions if q not in used_questions[chat_id]]
    q = random.choice(available_questions)

    # Thêm câu hỏi vào danh sách đã dùng
    used_questions[chat_id].append(q)
    current_question[chat_id] = q
    
    # Khởi tạo dữ liệu cho câu hỏi mới
    quiz_answers[chat_id] = {}
    quiz_participants[chat_id] = set()

    bot.send_message(chat_id, f"❓ Câu hỏi {len(used_questions[chat_id])}/{len(questions)}: {q['q']}\n⏰ Thời gian: 30 giây!")
    
    # Bắt đầu đếm ngược
    timer_thread = Thread(target=countdown_timer, args=(chat_id,))
    timer_thread.daemon = True
    timer_thread.start()

@bot.message_handler(func=lambda msg: msg.chat.id in current_question)
def answer_quiz(message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    
    # Kiểm tra xem người này đã trả lời chưa
    if chat_id in quiz_participants and user_id in quiz_participants[chat_id]:
        return  # Đã trả lời rồi, bỏ qua
    
    # Kiểm tra xem đã đủ 15 người trả lời chưa
    if chat_id in quiz_answers and len(quiz_answers[chat_id]) >= 15:
        return  # Đã đủ 15 người, bỏ qua
    
    q = current_question[chat_id]
    
    # Chuyển về chữ thường để so sánh
    user_answer = message.text.strip().lower()
    correct_answer = q['a'].lower()
    
    # Tách từ trong đáp án đúng
    answer_words = correct_answer.split()
    
    # Kiểm tra xem có ít nhất 1 từ khóa quan trọng trong câu trả lời không
    is_correct = False
    
    # Nếu đáp án chỉ có 1 từ, kiểm tra có chứa từ đó không
    if len(answer_words) == 1:
        if answer_words[0] in user_answer:
            is_correct = True
    else:
        # Nếu đáp án có nhiều từ, chỉ cần chứa ít nhất 1-2 từ quan trọng
        matched_words = 0
        for word in answer_words:
            if len(word) > 2 and word in user_answer:  # Bỏ qua các từ quá ngắn như "của", "là"
                matched_words += 1
        
        # Chấp nhận nếu có ít nhất 1 từ khóa quan trọng (với đáp án 2-3 từ) 
        # hoặc ít nhất 2 từ khóa (với đáp án dài hơn)
        if len(answer_words) <= 3 and matched_words >= 1:
            is_correct = True
        elif len(answer_words) > 3 and matched_words >= 2:
            is_correct = True
        # Hoặc kiểm tra theo cách cũ (chứa toàn bộ cụm từ)
        elif correct_answer in user_answer:
            is_correct = True
    
    # Lưu câu trả lời
    quiz_answers[chat_id][user_id] = {
        'user_name': message.from_user.first_name,
        'answer': user_answer,
        'is_correct': is_correct
    }
    
    # Đánh dấu người này đã trả lời
    quiz_participants[chat_id].add(user_id)
    
    # Nếu đã đủ 15 người trả lời, kết thúc ngay
    if len(quiz_answers[chat_id]) >= 15:
        end_quiz(chat_id)

# ------------------------
# GAME XÚC XẮC
# ------------------------
@bot.message_handler(commands=['dice'])
def dice_game(message):
    chat_id = message.chat.id
    
    # Kiểm tra quyền admin trong nhóm  
    if not is_admin(message):
        bot.send_message(chat_id, "Bạn có phải chủ của tớ đâu mờ nhắn lệnh /dice 🤭")
        return

    result = random.randint(3, 18)
    bot.send_message(chat_id, "🎲 Tôi đã tung 3 viên xúc xắc! Hãy đoán tổng (3-18).")

    def check_guess(m):
        return m.chat.id == chat_id and m.text.isdigit()

    @bot.message_handler(func=check_guess)
    def reveal_result(m):
        guess = int(m.text)
        if guess == result:
            reward = random.choice(rewards)
            bot.send_message(chat_id, f"🏆 {m.from_user.first_name} đoán {guess} đúng! {reward}")
        else:
            punish = random.choice(punishments)
            bot.send_message(chat_id, f"💀 {m.from_user.first_name} đoán {guess} sai! (Kết quả: {result}) → {punish}")
        bot.clear_step_handler_by_chat_id(chat_id)

# ------------------------
# HELP
# ------------------------
@bot.message_handler(commands=['help'])
def help_cmd(message):
    bot.send_message(message.chat.id, 
        "🤖 Lệnh chơi game:\n"
        "/quiz - Bot ra câu hỏi đố vui\n"
        "/dice - Bot tung 3 viên xúc xắc (3-18)\n"
        "/help - Xem hướng dẫn"
    )

# ------------------------
# Chạy bot + server
# ------------------------
if __name__ == "__main__":
    keep_alive()
    print("🤖 Bot đang chạy...")
    bot.infinity_polling()